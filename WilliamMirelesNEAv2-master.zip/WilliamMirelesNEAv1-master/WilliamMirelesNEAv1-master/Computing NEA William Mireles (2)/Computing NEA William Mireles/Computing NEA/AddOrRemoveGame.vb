﻿Public Class AddOrRemoveGame
    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click
        Try
            '  If the staff member has left any essential field blank, they are notified that they must populate each field required
            If BoughtOrSold.SelectedItem <> "Bought" Or BoughtOrSold.SelectedItem <> "Sold" Then
                MessageBox.Show("You can only buy or sell games using this form, please select one of the options from the drop down box", "Validation error", MessageBoxButtons.OK, MessageBoxIcon.Error)

            ElseIf txtTitle.Text = "" Or txtPrice.Text = "" Or txtGenre.Text = "" Or txtDeveloper.Text = "" Or txtCustomerID.Text = "" Then
                MessageBox.Show("Please ensure that all fields are filled out", "Validation error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                ' If the staff member has entered a game that has a negative price, they are notified that this is impossible and they must review their input
            ElseIf txtPrice.Text < 0 Or IsNumeric(txtPrice.Text) = False Then
                MessageBox.Show("Please review the price value, it cannot be negative nor composed of characters", "Validation error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                ' If they want to sell a game, and have rightfully left the GameID value as0, then this path is taken
            ElseIf BoughtOrSold.Text = "Bought" And txtGameID.Text = 0 Then


                ' Create connection to the database
                Dim conn As New System.Data.OleDb.OleDbConnection()
                ' Defines location of the database
                conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ipr0z\OneDrive\Desktop\MongooseGames.accdb"

                ' SQL (Structured Query Lanugage) statement which inserts what the staff member input into the database in the corresponding table
                Dim sql As String = "INSERT INTO Games (GameName,Price,Genre,Developer) VALUES ('" & txtTitle.Text & "', '" & txtPrice.Text & "', '" & txtGenre.Text & "', '" & txtDeveloper.Text & "')"


                Dim sqlCom As New System.Data.OleDb.OleDbCommand(sql)

                ' Staff member is notified of their success of their required task.
                MessageBox.Show("Game added to system", "Appending of game successful")
                ' Current form is hidden to allow the staff member to focus their attention on the AddToRecent form
                Me.Hide()
                ' AddToRecent Form is shown, which asks the staff member if they wish to log the transaction into the system
                AddToRecent.Show()
                ' Close database connection

                'Open Database Connection again
                sqlCom.Connection = conn
                conn.Open()

                ' Carry out the sql statement
                Dim sqlRead As System.Data.OleDb.OleDbDataReader = sqlCom.ExecuteReader()

                ' Close the connection to the database
                conn.Close()

                ' IF the staff member is buying a game from a customer and has populated the GameID text box they are infomred that this is not needed as it won't currently have a GameID since it's being introduced into the system
            ElseIf BoughtOrSold.Text = "Bought" And txtGameID.Text <> 0 Then
                MessageBox.Show("Please leave the GameID textbox as 0 since it is a game that is being introduced in the system and thus will not currently have a determined GameID", "Validation error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                txtGameID.Text = "0"

                ' This is now for when the staff member wants to remove a game from the database due to it being sold
            ElseIf BoughtOrSold.Text = "Sold" Then
                Dim conn As New System.Data.OleDb.OleDbConnection()
                ' Define database location
                conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ipr0z\OneDrive\Desktop\MongooseGames.accdb"
                ' SQL statement which ensures that the game that the staff member is selling to a customer actually exists in the system
                Dim sqlValidation As String = "SELECT * FROM Games WHERE GameID = " & txtGameID.Text & " AND GameName = '" & txtTitle.Text & "' AND Price = '" & txtPrice.Text & "' AND Genre = '" & txtGenre.Text & "' AND Developer = '" & txtDeveloper.Text & "'"
                ' Allows sql to communicate with database
                Dim sqlComValidation As New System.Data.OleDb.OleDbCommand(sqlValidation)
                ' Executes SQL statement against database

                sqlComValidation.Connection = conn
                'Open Database Connection
                conn.Open()
                Dim sqlReadValidation As System.Data.OleDb.OleDbDataReader = sqlComValidation.ExecuteReader()

                ' If the game actually exists in the system, then the game is subsequently sold to the customer
                If sqlReadValidation.Read() Then
                    ' Create connection to the database
                    Dim conn1 As New System.Data.OleDb.OleDbConnection()
                    ' Define location of the database
                    conn1.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ipr0z\OneDrive\Desktop\MongooseGames.accdb"

                    ' SQL (Structured Query Lanugage) statement which deletes the game that the staff member has referred to (using its ID) from the database
                    Dim sql As String = "DELETE * FROM Games WHERE (GameID) = (" & txtGameID.Text & ")"


                    Dim sqlCom As New System.Data.OleDb.OleDbCommand(sql)
                    ' Staff member is notififed of their success of their required task.
                    MessageBox.Show("Game removed from system", "Removal of game successful")
                    ' Current form is hidden to allow the staff member to focus their attention on the AddToRecent form
                    Me.Hide()
                    ' AddToRecent Form is shown, which asks the staff member if they wish to log the transaction into the system
                    AddToRecent.Show()

                    ' Open connection with sql
                    sqlCom.Connection = conn1
                    conn1.Open()

                    ' Carry out the sql statement
                    Dim sqlRead As System.Data.OleDb.OleDbDataReader = sqlCom.ExecuteReader()

                    ' Close the connection to the database
                    conn.Close()
                    ' If the GameID textbox is left blank, the staff member is notified that they are required to enter this seeing as they are selling a game to a customer and thus does have an existing gameID as it exists in the database currently
                ElseIf txtGameID.Text = "" Or txtGameID.Text = 0 Then
                    MessageBox.Show("Please enter the GameID of the current game you wish to sell to the customer", "Validation error", MessageBoxButtons.OK, MessageBoxIcon.Error)


                Else
                    MessageBox.Show("The game you're trying to sell to a customer does not exist on the system, or you have inputted the game's details incorrectly. Please try again", "Validation error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End If
            ' If any sort of error happens, this is caught to prevent the system from crashing, the staff member is then told to revise what they have input as it is likely they have entered erroneous data
        Catch ex As Exception
            MessageBox.Show("An error has occurred, please revise the inputs", "Data compilation error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' When main menu button is clicked
    Private Sub BtnMainMenu_Click(sender As Object, e As EventArgs) Handles BtnMainMenu.Click
        ' Hides current menu
        Me.Hide()
        ' Displays the staff main menu
        StaffMenu.Show()
    End Sub
End Class