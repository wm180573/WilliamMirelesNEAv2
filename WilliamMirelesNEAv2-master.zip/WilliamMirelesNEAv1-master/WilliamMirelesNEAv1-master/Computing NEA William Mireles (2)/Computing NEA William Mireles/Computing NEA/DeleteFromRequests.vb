﻿Public Class DeleteFromRequests
    Private Sub BtnYes_Click(sender As Object, e As EventArgs) Handles BtnYes.Click
        ' Create connection to the database
        Dim conn As New System.Data.OleDb.OleDbConnection()
        ' Define location of the database
        conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ipr0z\OneDrive\Desktop\MongooseGames.accdb"

        ' SQL (Structured Query Lanugage) statement which deletes the request that the staff member has just dealt with from the system
        Dim sql As String = "DELETE * FROM CustRequests WHERE (RequestID) = (" & RequestReply.txtRequestID.Text & ")"


        Dim sqlCom As New System.Data.OleDb.OleDbCommand(sql)
        ' Staff member is notififed of their success of their required task.
        MessageBox.Show("Request removed from system, you will now be redirected to the main menu screen", "Removal of request successful")
        ' Current form is hidden
        Me.Hide()
        ' redirected to main menu
        StaffMenu.Show()

        ' Open connection with sql
        sqlCom.Connection = conn
        ' Open connection to database
        conn.Open()

        ' Carry out the sql statement
        Dim sqlRead As System.Data.OleDb.OleDbDataReader = sqlCom.ExecuteReader()

        ' Close the connection to the database
        conn.Close()
    End Sub

    Private Sub BtnNo_Click(sender As Object, e As EventArgs) Handles BtnNo.Click
        ' Hides current form
        Me.Hide()
        ' Shows menu
        StaffMenu.Show()
    End Sub
End Class