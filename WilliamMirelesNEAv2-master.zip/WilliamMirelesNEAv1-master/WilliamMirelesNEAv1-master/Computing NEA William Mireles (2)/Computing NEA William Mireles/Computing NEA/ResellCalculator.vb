﻿Public Class ResellCalculator
    Private Sub BtnCalculate_Click(sender As Object, e As EventArgs) Handles BtnCalculate.Click
        ' Converts the string input to integer to allow the value to be manipulated mathematically
        Dim PricePaid As Integer = Convert.ToDouble(txtPricePaid.Text)
        ' The price is incremented by 25%
        txtResellPrice.Text = PricePaid * 1.25

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' Hides current form
        Me.Hide()
        ' Shows staff menu
        StaffMenu.Show()
    End Sub
End Class