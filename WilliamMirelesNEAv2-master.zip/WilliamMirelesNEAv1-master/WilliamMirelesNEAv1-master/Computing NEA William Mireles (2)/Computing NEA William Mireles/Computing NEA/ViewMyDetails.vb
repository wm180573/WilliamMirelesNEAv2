﻿Public Class ViewMyDetails
    Private Sub ViewMyDetails_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Define connection
        Dim conn As New System.Data.OleDb.OleDbConnection()
        ' Define database location for connection
        conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ipr0z\OneDrive\Desktop\MongooseGames.accdb"
        ' Retrieves the record of the customer who is logged in
        Dim sql As String = "SELECT CustUser,CustPass,FirstName,Surname,PhoneNum,Address,County,Town,Postcode FROM Customers WHERE (CustUser) = ('" & CustomerLogin.txtUsername.Text & "')"
        ' Allows sql command to communicate with the data source
        Dim sqlCom As New System.Data.OleDb.OleDbCommand(sql)
        'Open Database Connection
        sqlCom.Connection = conn
        conn.Open()
        ' Provides a way of reading the data rows from the database
        Dim sqlRead As System.Data.OleDb.OleDbDataReader = sqlCom.ExecuteReader()
        ' Executes following code if there are records found
        If sqlRead.HasRows Then
            ' This while loop populates the relevant textbox with the corresponding information from the database until finished.
            While sqlRead.Read()
                txtUsername.Text = sqlRead.Item("CustUser")
                txtPassword.Text = sqlRead.Item("CustPass")
                txtFirstName.Text = sqlRead.Item("FirstName")
                txtSurname.Text = sqlRead.Item("Surname")
                txtTelephone.Text = sqlRead.Item("PhoneNum")
                txtAddress.Text = sqlRead.Item("Address")
                txtCounty.Text = sqlRead.Item("County")
                txtTown.Text = sqlRead.Item("Town")
                txtPostcode.Text = sqlRead.Item("Postcode")
            End While
            ' Close connection between sql and database
            sqlRead.Close()
        Else
            ' If they have missing details or no details stored about them on the system, they are notified about this and advised to report this to a member of staff
            MessageBox.Show("No details could be found about you, please report this to a member of staff")
        End If
        ' Connection of the database is closed
        conn.Close()
    End Sub

    Private Sub BtnMainMenu_Click(sender As Object, e As EventArgs) Handles BtnMainMenu.Click
        ' hides current form
        Me.Hide()
        ' shows customer menu
        CustomerMenu.Show()
    End Sub
End Class